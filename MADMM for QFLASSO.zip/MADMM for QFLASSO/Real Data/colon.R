source("Thld.R")#Soft threshold operator
source("PL.R")#Quantile loss operator
source("qfLasso_M")#MADMM for QFLASSO
#####
colon=read.table("colon-cancer.txt",head=FALSE)
str(colon)
y_label=colon$V1
X0=matrix(0,nrow = 62,ncol =2000)
for(i in 1:62){
  for(j in 1:2000){
    X0[i,j]=as.numeric(strsplit(as.character(colon[,(j+1)]),":")[[i]][2])
  }
}  
str(X0)

p=ncol(X0)
n=nrow(X0)

#
F_matrix<-function(p)
{
  F=matrix(0,p-1,p)
  for(i in 1:(p-1))
  {
    F[i,i]=1
    F[i,i+1]=-1
  }
  return(F)
}
F=F_matrix(p)
#
FTF=function(p){
  FTF=matrix(0,p,p)
  F1 = diag(p)*0
  diag(F1[-1,-p]) = -1
  F2=t(F1)
  F3=diag(c(rep(2,p-1),1),p)
  FTF=F1+F2+F3
  return(FTF)
}
#

alpha=0.9
lambda=1/n*alpha*(1-alpha)*sqrt(log(p)/n)
lambda1=alpha*lambda#0.0001
lambda2=(1-alpha)*lambda
qfLasso=qfLasso_M(y_label,X0,lambda1,lambda2,tau)
#plot(beta)
beta_r=qfLasso$a_u
length(which(abs(beta_r)>0.01))#the number of nonzero
length(which(abs(F%*%beta_r)>0.01))#the number of nonzero
plot(beta_r)
qfLasso$K
62-length(which(sign(X0%*%beta_r)-y_label==0))

con=qfLasso$con[1:qfLasso$K]

plot(con)
write.table(con,file = "con_colon")
