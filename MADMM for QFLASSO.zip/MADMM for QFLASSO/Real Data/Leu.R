source("Thld.R")#Soft threshold operator
source("PL.R")#Quantile loss operator
source("qfLasso_M")#MADMM for QFLASSO

###
leu=read.table("leu.txt",head=FALSE)
str(leu)
#####traning
y_label=leu$V1
Y=diag(y_label)
X0=matrix(0,nrow = 38,ncol =7129)
for(i in 1:38){
  for(j in 1:7129){
    X0[i,j]=as.numeric(strsplit(leu[,(j+1)],":")[[i]][2])
  }
}  
str(X0)
#####test
leut=read.table("leut.txt",head=FALSE)
str(leut)
y_labelt=leut$V1
X0t=matrix(0,nrow = 34,ncol =7129)
for(i in 1:34){
  for(j in 1:7129){
    X0t[i,j]=as.numeric(strsplit(leut[,(j+1)],":")[[i]][2])
  }
}  


###
p=ncol(X0)
F_matrix<-function(p)
{
  F=matrix(0,p-1,p)
  for(i in 1:(p-1))
  {
    F[i,i]=1
    F[i,i+1]=-1
  }
  return(F)
}
F=F_matrix(p)
#
FTF=function(p){
  FTF=matrix(0,p,p)
  F1 = diag(p)*0
  diag(F1[-1,-p]) = -1
  F2=t(F1)
  F3=diag(c(rep(2,p-1),1),p)
  FTF=F1+F2+F3
  return(FTF)
}
X=rbind(X0,X0t)
y=c(y_label,y_labelt)
#
alpha=0.5
lambda=1/n*alpha*(1-alpha)*sqrt(log(p)/n)
lambda1=alpha*lambda#0.0001
lambda2=(1-alpha)*lambda
qfLasso=qfLasso_M(y,X,lambda1,lambda2,tau)
#plot(beta)
beta_r=qfLasso$a_u
length(which(abs(beta_r)>0.01))#the number of nonzero
length(which(abs(F%*%beta_r)>0.01))#the number of nonzero
plot(beta_r)
qfLasso$K
38-length(which(sign(X0%*%beta_r)-y_label==0))

#####test
leut=read.table("leut.txt",head=FALSE)
str(leut)
y_labelt=leut$V1
X0t=matrix(0,nrow = 34,ncol =7129)
for(i in 1:34){
  for(j in 1:7129){
    X0t[i,j]=as.numeric(strsplit(leut[,(j+1)],":")[[i]][2])
  }
}  
str(X0t)
34-length(which(sign(X0t%*%beta_r)-y_labelt==0))

con2=qfLasso$con[1:qfLasso$K]

plot(con2)
write.table(con2,file = "con_leu")

