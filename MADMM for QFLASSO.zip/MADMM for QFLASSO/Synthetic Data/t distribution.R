source("random_t.R")#Generate t distribution random number
source("random_c.R")#Generate Cauchy distribution random number
source("random_n.R")#Generate normal distribution random number
source("Thld.R")#Soft threshold operator
source("PL.R")#Quantile loss operator
source("qfLasso_M")#MADMM for QFLASSO
#####
n=720
p=2560
set.seed(66666)
index=1:80
ind=sample(index,10)
beta=rep(0,p)
for (i in 1:10) {
  beta[((ind[i]-1)*32+1):((ind[i]-1)*32+32)]=rep(runif(1,-3,3),32)
}
plot(beta)

rand=random_t(n,p,beta)
y=rand$y
X=rand$X
X=scale(X,center=FALSE,scale=T)

F_matrix<-function(p)
{
  F=matrix(0,p-1,p)
  for(i in 1:(p-1))
  {
    F[i,i]=1
    F[i,i+1]=-1
  }
  return(F)
}
F=F_matrix(p)
#
FTF=function(p){
  if(p==2){FTF=matrix(c(1,-1,-1,1),2,2)}else{
    FTF=matrix(0,p,p)
    F1 = diag(p)*0
    diag(F1[-1,-p]) = -1
    F2=t(F1)
    F3=diag(c(rep(2,p-1),1),p)
    FTF=F1+F2+F3}
  return(FTF)
}

###
lambda=sqrt(log(p)/n)
alpha=0.1
lambda1=alpha*lambda#0.0001
lambda2=(1-alpha)*lambda


tau=0.9 #0.1,0.5,0.9
qfLasso=qfLasso_M(y,X,lambda1,lambda2,tau)
plot(beta)
beta_r=qfLasso$a_u
plot(beta_r)
qfLasso$K

### i in G
dd1=rep(0,320)
for (i in 1:10) {
  dd1[((i-1)*32+1):(32*i)]=abs(beta[((ind[i]-1)*32+1):((ind[i]-1)*32+32)]-
                                 beta_r[((ind[i]-1)*32+1):((ind[i]-1)*32+32)])
}
length(which(dd1<0.1))
max(dd1)

### in in G^c
dd2=rep(0,2240)
ind2=index[-ind]
for (i in 1:70) {
  dd2[(32*(i-1)+1):(32*i)]=abs(beta_r[((ind2[i]-1)*32+1):((ind2[i]-1)*32+32)])
  
}
length(which(dd2<0.1))
max(dd2)
